import { BusinessFormData, ConfigStatus, CreatedAgentResponse, ElevenLabsVoice, Rulebook } from './types';

export async function fetchConfigStatus(): Promise<ConfigStatus> {
  const res = await fetch('/api/config/status');
  if (!res.ok) throw new Error('Failed to load server configuration');
  return res.json();
}

export async function generateRulebook(data: BusinessFormData): Promise<Rulebook> {
  const payload = {
    businessName: data.businessName,
    industry: data.industry,
    description: data.description,
    targetAudience: data.targetAudience,
    desiredTone: data.desiredTone,
    keyServices: data.keyServices ? data.keyServices.split('\n').filter(s => s.trim().length > 0) : [],
    customConstraints: data.customConstraints ? data.customConstraints.split('\n').filter(s => s.trim().length > 0) : []
  };

  const res = await fetch('/api/rulebook/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const body = await res.json();
  if (!res.ok || !body.success) {
    throw new Error(body.error || 'Failed to generate Rulebook');
  }

  return body.rulebook;
}

export async function fetchVoices(): Promise<{ voices: ElevenLabsVoice[]; isLive: boolean }> {
  const res = await fetch('/api/elevenlabs/voices');
  const body = await res.json();
  if (!res.ok || !body.success) {
    throw new Error(body.error || 'Failed to load voices');
  }
  return { voices: body.voices, isLive: body.isLive };
}

export async function createAgent(
  rulebook: Rulebook,
  voiceId?: string,
  agentNameOverride?: string
): Promise<CreatedAgentResponse> {
  const res = await fetch('/api/elevenlabs/agents', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      rulebook,
      voiceId,
      agentNameOverride
    })
  });

  const body = await res.json();
  if (!res.ok || !body.success) {
    throw new Error(body.error || 'Failed to create voice agent on ElevenLabs');
  }

  return body.data;
}
