import React, { useState } from 'react';
import {
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  Code,
  Radio,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { CreatedAgentResponse, Rulebook } from '../types';

interface AgentSuccessModalProps {
  agent: CreatedAgentResponse;
  rulebook: Rulebook;
  onReset: () => void;
}

export const AgentSuccessModal: React.FC<AgentSuccessModalProps> = ({
  agent,
  rulebook,
  onReset
}) => {
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  const copySnippet = () => {
    navigator.clipboard.writeText(agent.widgetSnippet);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const copyId = () => {
    navigator.clipboard.writeText(agent.agentId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950/40 border border-emerald-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                Live on ElevenLabs
              </span>
            </div>
            <h2 className="text-2xl font-extrabold text-white mt-1">
              {agent.name}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Voice agent initialized with your custom rulebook, prompt, and guardrails.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Create Another Agent
        </button>
      </div>

      {/* Quick stats and Links */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Agent ID Box */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-3">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              ElevenLabs Agent ID
            </span>
            <div className="flex items-center justify-between mt-1.5 font-mono text-sm text-indigo-300 bg-slate-900/90 px-3 py-2 rounded-lg border border-slate-800">
              <span className="truncate">{agent.agentId}</span>
              <button
                type="button"
                onClick={copyId}
                className="ml-2 text-slate-400 hover:text-white"
                title="Copy Agent ID"
              >
                {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            Use this identifier in the ElevenLabs SDK or Python/Node clients.
          </p>
        </div>

        {/* Live Dashboard Button */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-3">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              ElevenLabs Dashboard & Live Call Tester
            </span>
            <p className="text-xs text-slate-300 mt-1">
              Talk directly with your agent, view latency metrics, and test conversation flows.
            </p>
          </div>

          <a
            href={agent.dashboardUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors shadow-md shadow-indigo-600/30"
          >
            <span>Open in ElevenLabs Console</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Website Embed Snippet */}
      <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-indigo-300 uppercase tracking-wider">
            <Code className="w-4 h-4" />
            Website Floating Voice Widget Snippet
          </span>
          <button
            type="button"
            onClick={copySnippet}
            className="inline-flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            {copiedSnippet ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Snippet</span>
              </>
            )}
          </button>
        </div>
        <p className="text-[11px] text-slate-400">
          Paste this HTML code anywhere in a website to embed a live interactive audio call button:
        </p>
        <pre className="p-3 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs text-emerald-300 overflow-x-auto">
          {agent.widgetSnippet}
        </pre>
      </div>

      {/* Hackathon Presentation Tips */}
      <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-xs text-indigo-200 space-y-2">
        <div className="font-semibold text-indigo-300 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4" />
          Hackathon Presentation Tip
        </div>
        <p className="leading-relaxed">
          In your live demo:
          1. Show how VoiceForge AI turns an unformatted business description into a precise, guardrailed Rulebook in seconds.
          2. Open the ElevenLabs link to have a real-time spoken conversation with the agent.
          3. Test asking a question that breaks the guardrails (e.g. asking for a medical diagnosis) to show judges how strictly the AI abides by the Rulebook.
        </p>
      </div>
    </div>
  );
};
