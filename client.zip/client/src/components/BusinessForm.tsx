import React from 'react';
import { Sparkles, Building2, Stethoscope, Home, Coffee, Laptop, Loader2, ArrowRight } from 'lucide-react';
import { BusinessFormData } from '../types';

interface BusinessFormProps {
  formData: BusinessFormData;
  setFormData: React.Dispatch<React.SetStateAction<BusinessFormData>>;
  onGenerate: () => void;
  isLoading: boolean;
}

const PRESETS: Array<{
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  data: BusinessFormData;
}> = [
  {
    label: 'SmileCare Dental',
    icon: Stethoscope,
    data: {
      businessName: 'SmileCare Family Dental',
      industry: 'Healthcare & Dentistry',
      description: 'A modern dental clinic providing routine preventive exams, emergency tooth extraction, teeth whitening, and pediatric dentistry. Open Monday through Friday from 8:30 AM to 5:00 PM.',
      targetAudience: 'Local families, working professionals, and emergency dental patients',
      desiredTone: 'Warm, reassuring, empathetic, and clear',
      keyServices: 'Routine Cleanings & X-Rays\nTeeth Whitening Treatments\nEmergency Tooth Pain Triage\nPediatric Dentistry Appointments',
      customConstraints: 'Never give medical diagnoses over the phone.\nAdvise calling 911 immediately if experiencing uncontrolled bleeding or breathing issues.\nDo not quote final insurance coverage numbers; advise bringing insurance card.'
    }
  },
  {
    label: 'Apex Real Estate',
    icon: Home,
    data: {
      businessName: 'Apex Prime Properties',
      industry: 'Real Estate & Property Management',
      description: 'A boutique luxury real estate firm helping clients buy, sell, and lease modern apartments and residential homes across the metropolitan area.',
      targetAudience: 'Homebuyers, property investors, and tenants looking for residential rentals',
      desiredTone: 'Professional, articulate, enthusiastic, and consultative',
      keyServices: 'Private Property Viewings\nHome Valuation Consultations\nRental Application Assistance\nListing Price Guidance',
      customConstraints: 'Do not promise property availability without checking live MLS records.\nNever disclose landlord private contact information.'
    }
  },
  {
    label: 'Urban Roast Cafe',
    icon: Coffee,
    data: {
      businessName: 'Urban Roast Artisan Cafe',
      industry: 'Hospitality & Dining',
      description: 'An independent coffee roaster and bakery known for specialty pour-overs, artisan sourdough pastries, and small private group bookings.',
      targetAudience: 'Coffee enthusiasts, remote workers, and weekend brunch crowds',
      desiredTone: 'Vibrant, welcoming, upbeat, and polite',
      keyServices: 'Table Reservations (groups > 6)\nWhole Bean Coffee Orders\nCatering & Pastry Platters\nToday\'s Seasonal Specials',
      customConstraints: 'Inform callers we do not take reservations for parties under 4 during peak weekend brunch (walk-ins only).\nDirect online takeout orders to our website.'
    }
  },
  {
    label: 'CloudFlow SaaS',
    icon: Laptop,
    data: {
      businessName: 'CloudFlow Systems',
      industry: 'Technology & B2B SaaS',
      description: 'An AI-powered workflow automation platform for small businesses. Handles technical triage, product demos, and subscription tier inquiries.',
      targetAudience: 'Business operations managers, founders, and IT specialists',
      desiredTone: 'Sharp, knowledgeable, solution-oriented, and efficient',
      keyServices: 'Product Demo Scheduling\nAccount Login Support\nEnterprise Custom Plan Quotes\nAPI Status & Maintenance Checks',
      customConstraints: 'Never ask callers for their passwords or full credit card numbers.\nEscalate P1 outages directly to the on-call engineering channel.'
    }
  }
];

export const BusinessForm: React.FC<BusinessFormProps> = ({
  formData,
  setFormData,
  onGenerate,
  isLoading
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const applyPreset = (presetData: BusinessFormData) => {
    setFormData(presetData);
  };

  return (
    <div className="space-y-6">
      {/* Intro & Preset Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-400" />
              1. Business Blueprint & Intent
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Describe your business or click a preset below to auto-fill realistic sample details.
            </p>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Presets:</span>
            {PRESETS.map((preset) => {
              const Icon = preset.icon;
              return (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => applyPreset(preset.data)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600/30 hover:border-indigo-500/50 border border-slate-700/80 text-xs font-medium text-slate-200 transition-all active:scale-95"
                >
                  <Icon className="w-3.5 h-3.5 text-indigo-400" />
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Form Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Business Name
            </label>
            <input
              type="text"
              name="businessName"
              value={formData.businessName}
              onChange={handleChange}
              placeholder="e.g. SmileCare Family Dental"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Industry / Sector
            </label>
            <input
              type="text"
              name="industry"
              value={formData.industry}
              onChange={handleChange}
              placeholder="e.g. Healthcare, Real Estate, Hospitality"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Business Description & Goals <span className="text-rose-400">*</span>
            </label>
            <textarea
              name="description"
              rows={3}
              required
              value={formData.description}
              onChange={handleChange}
              placeholder="Explain what the company does, working hours, and what the voice agent should accomplish during customer calls..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Target Audience
            </label>
            <input
              type="text"
              name="targetAudience"
              value={formData.targetAudience}
              onChange={handleChange}
              placeholder="e.g. Existing patients, new homebuyers, busy professionals"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Desired Tone & Personality
            </label>
            <input
              type="text"
              name="desiredTone"
              value={formData.desiredTone}
              onChange={handleChange}
              placeholder="e.g. Warm, empathetic, professional, and reassuring"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Key Services (1 per line)
            </label>
            <textarea
              name="keyServices"
              rows={3}
              value={formData.keyServices}
              onChange={handleChange}
              placeholder="Routine Checkups&#10;Emergency Pain Care&#10;Teeth Whitening"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono text-xs transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Custom Guardrails & Boundaries (1 per line)
            </label>
            <textarea
              name="customConstraints"
              rows={3}
              value={formData.customConstraints}
              onChange={handleChange}
              placeholder="Never give medical diagnoses over the phone&#10;Do not quote fixed prices without an examination"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono text-xs transition-colors"
            />
          </div>
        </div>

        {/* Generate Button */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
          <p className="text-xs text-slate-400">
            VoiceForge AI will turn this input into a structured, production-ready JSON Rulebook.
          </p>

          <button
            type="button"
            onClick={onGenerate}
            disabled={isLoading || !formData.description.trim()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Architecting Rulebook...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-indigo-200" />
                <span>Generate Rulebook</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
