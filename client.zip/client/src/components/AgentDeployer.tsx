import React, { useState, useEffect } from 'react';
import {
  Mic,
  Volume2,
  Play,
  Pause,
  Sliders,
  Sparkles,
  Loader2,
  ArrowLeft,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { ElevenLabsVoice, Rulebook, ConfigStatus } from '../types';
import { fetchVoices } from '../api';

interface AgentDeployerProps {
  rulebook: Rulebook;
  config: ConfigStatus | null;
  onDeploy: (voiceId: string, agentName: string) => void;
  onBack: () => void;
  isLoading: boolean;
}

export const AgentDeployer: React.FC<AgentDeployerProps> = ({
  rulebook,
  config,
  onDeploy,
  onBack,
  isLoading
}) => {
  const [voices, setVoices] = useState<ElevenLabsVoice[]>([]);
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>(
    rulebook.voiceSettings?.suggestedVoiceId || '21m00Tcm4TlvDq8ikWAM'
  );
  const [agentName, setAgentName] = useState<string>(rulebook.agentName);
  const [loadingVoices, setLoadingVoices] = useState<boolean>(true);
  const [isLiveVoices, setIsLiveVoices] = useState<boolean>(false);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    let mounted = true;
    fetchVoices()
      .then((data) => {
        if (mounted) {
          setVoices(data.voices);
          setIsLiveVoices(data.isLive);
          if (data.voices.length > 0 && !selectedVoiceId) {
            setSelectedVoiceId(data.voices[0].voice_id);
          }
        }
      })
      .catch((err) => console.error('Voice fetch error:', err))
      .finally(() => {
        if (mounted) setLoadingVoices(false);
      });

    return () => {
      mounted = false;
      if (audioElement) {
        audioElement.pause();
      }
    };
  }, []);

  const handlePlayVoice = (previewUrl?: string, voiceId?: string) => {
    if (!previewUrl || !voiceId) return;

    if (playingAudio === voiceId && audioElement) {
      audioElement.pause();
      setPlayingAudio(null);
      return;
    }

    if (audioElement) {
      audioElement.pause();
    }

    const audio = new Audio(previewUrl);
    setAudioElement(audio);
    setPlayingAudio(voiceId);

    audio.play();
    audio.onended = () => {
      setPlayingAudio(null);
    };
  };

  const handleDeployClick = () => {
    onDeploy(selectedVoiceId, agentName);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Mic className="w-5 h-5 text-indigo-400" />
          3. Voice Selection & ElevenLabs Deployment
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Choose a natural neural voice for your agent and push the configured Rulebook to the ElevenLabs Conversational AI platform.
        </p>
      </div>

      {/* Agent Name Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
            Agent Display Name
          </label>
          <input
            type="text"
            value={agentName}
            onChange={(e) => setAgentName(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
          />
          <span className="text-[11px] text-slate-500 mt-1 block">
            This name appears in your ElevenLabs dashboard and widget title.
          </span>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
            Language & Region
          </label>
          <input
            type="text"
            value="English (en) - Conversational AI Turbo"
            readOnly
            className="w-full bg-slate-950/60 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-400 cursor-not-allowed"
          />
          <span className="text-[11px] text-slate-500 mt-1 block">
            Optimized for ultra-low latency telephone conversations.
          </span>
        </div>
      </div>

      {/* Voice Selection Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 uppercase tracking-wider">
            <Volume2 className="w-4 h-4" />
            Select Voice Model ({voices.length} Available)
          </label>
          {isLiveVoices ? (
            <span className="text-[11px] font-medium text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Live ElevenLabs Voices Loaded
            </span>
          ) : (
            <span className="text-[11px] font-medium text-amber-400/90 flex items-center gap-1">
              Curated ElevenLabs Voice Presets
            </span>
          )}
        </div>

        {loadingVoices ? (
          <div className="p-8 text-center text-slate-500 text-xs flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
            Loading ElevenLabs voices...
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {voices.map((voice) => {
              const isSelected = selectedVoiceId === voice.voice_id;
              const isPlaying = playingAudio === voice.voice_id;

              return (
                <div
                  key={voice.voice_id}
                  onClick={() => setSelectedVoiceId(voice.voice_id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    isSelected
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/10'
                      : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{voice.name}</span>
                        {voice.category && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 uppercase font-mono">
                            {voice.category}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                        {voice.description || 'Natural sounding conversational AI voice'}
                      </p>
                    </div>

                    <div className="shrink-0">
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          isSelected
                            ? 'border-indigo-500 bg-indigo-500'
                            : 'border-slate-700 bg-slate-900'
                        }`}
                      >
                        {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                    <span className="font-mono text-[10px] text-slate-500 truncate max-w-[140px]">
                      ID: {voice.voice_id.slice(0, 10)}...
                    </span>

                    {voice.preview_url && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePlayVoice(voice.preview_url, voice.voice_id);
                        }}
                        className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-400 hover:text-indigo-300"
                      >
                        {isPlaying ? (
                          <>
                            <Pause className="w-3 h-3" /> Stop
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3" /> Sample
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Deploy warning if no API key is in .env */}
      {!config?.hasElevenLabsKey && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1">
          <div className="font-semibold flex items-center gap-1.5 text-amber-300">
            <AlertCircle className="w-4 h-4" />
            ElevenLabs API Key Required
          </div>
          <p>
            You need to provide your ElevenLabs API key in <code className="bg-amber-950/80 px-1 py-0.5 rounded font-mono">server/.env</code> to make live API calls.
            If you click Create without a key, the backend will prompt you to configure it.
          </p>
        </div>
      )}

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
        <button
          type="button"
          onClick={onBack}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Rulebook
        </button>

        <button
          type="button"
          onClick={handleDeployClick}
          disabled={isLoading || !agentName.trim()}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-indigo-600 to-violet-600 hover:from-emerald-500 hover:to-violet-500 disabled:opacity-50 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Creating Voice Agent in ElevenLabs...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-emerald-300" />
              <span>Create ElevenLabs Voice Agent</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
