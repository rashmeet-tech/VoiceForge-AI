import React from 'react';
import { KeyRound, ExternalLink, Sparkles } from 'lucide-react';
import { ConfigStatus } from '../types';

interface StatusBannerProps {
  config: ConfigStatus | null;
}

export const StatusBanner: React.FC<StatusBannerProps> = ({ config }) => {
  if (config?.hasElevenLabsKey) {
    return null; // All good, no warning needed
  }

  return (
    <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border-b border-amber-500/20 px-4 py-2.5 text-xs text-amber-200">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Beginner Setup:</strong> To create live voice agents on ElevenLabs, add your API key in{' '}
            <code className="bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-500/30 font-mono text-amber-300">
              server/.env
            </code>{' '}
            as <code className="font-mono text-amber-300">ELEVENLABS_API_KEY=...</code> and restart the server.
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-amber-400/80">Rulebook generation works right away!</span>
          <a
            href="https://elevenlabs.io"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 font-semibold text-amber-300 hover:text-white underline underline-offset-2"
          >
            Get ElevenLabs Key <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
