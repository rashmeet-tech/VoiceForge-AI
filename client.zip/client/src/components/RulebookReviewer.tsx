import React, { useState, useEffect } from 'react';
import {
  FileCode2,
  SlidersHorizontal,
  Copy,
  Check,
  ShieldAlert,
  MessageSquare,
  BookOpen,
  Plus,
  Trash2,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  AlertTriangle
} from 'lucide-react';
import { Rulebook, KnowledgeItem } from '../types';

interface RulebookReviewerProps {
  rulebook: Rulebook;
  setRulebook: React.Dispatch<React.SetStateAction<Rulebook | null>>;
  onProceed: () => void;
  onBack: () => void;
}

export const RulebookReviewer: React.FC<RulebookReviewerProps> = ({
  rulebook,
  setRulebook,
  onProceed,
  onBack
}) => {
  const [activeTab, setActiveTab] = useState<'structured' | 'json'>('structured');
  const [jsonText, setJsonText] = useState<string>('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Sync state to json string on mount or tab change
  useEffect(() => {
    setJsonText(JSON.stringify(rulebook, null, 2));
    setJsonError(null);
  }, [rulebook]);

  const handleJsonChange = (val: string) => {
    setJsonText(val);
    try {
      const parsed = JSON.parse(val);
      setJsonError(null);
      setRulebook(parsed);
    } catch (e: any) {
      setJsonError(e.message || 'Invalid JSON syntax');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(JSON.stringify(rulebook, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateField = (path: string, val: any) => {
    setRulebook((prev) => {
      if (!prev) return prev;
      const clone = { ...prev };
      if (path === 'agentName') clone.agentName = val;
      if (path === 'businessName') clone.businessName = val;
      if (path === 'industry') clone.industry = val;
      if (path === 'primaryGoal') clone.primaryGoal = val;
      if (path === 'systemPrompt') clone.systemPrompt = val;
      if (path === 'firstMessage') clone.conversationFlow = { ...clone.conversationFlow, firstMessage: val };
      if (path === 'fallbackMessage') clone.conversationFlow = { ...clone.conversationFlow, fallbackMessage: val };
      return clone;
    });
  };

  const updateKbItem = (index: number, key: keyof KnowledgeItem, val: string) => {
    setRulebook((prev) => {
      if (!prev) return prev;
      const kb = [...prev.knowledgeBase];
      kb[index] = { ...kb[index], [key]: val };
      return { ...prev, knowledgeBase: kb };
    });
  };

  const addKbItem = () => {
    setRulebook((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        knowledgeBase: [...prev.knowledgeBase, { topic: 'New Topic', details: 'Describe facts here...' }]
      };
    });
  };

  const removeKbItem = (index: number) => {
    setRulebook((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        knowledgeBase: prev.knowledgeBase.filter((_, i) => i !== index)
      };
    });
  };

  const updateGuardrail = (index: number, val: string) => {
    setRulebook((prev) => {
      if (!prev) return prev;
      const rails = [...prev.guardrails];
      rails[index] = val;
      return { ...prev, guardrails: rails };
    });
  };

  const addGuardrail = () => {
    setRulebook((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        guardrails: [...prev.guardrails, 'New boundary or limitation for the voice agent']
      };
    });
  };

  const removeGuardrail = (index: number) => {
    setRulebook((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        guardrails: prev.guardrails.filter((_, i) => i !== index)
      };
    });
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-6">
      {/* Header and Mode switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileCode2 className="w-5 h-5 text-indigo-400" />
              2. Review & Refine AI Rulebook
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
              Structured JSON Validated
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Review the agent's prompt, guardrails, and knowledge base before deploying to ElevenLabs.
          </p>
        </div>

        {/* View Switcher & Copy */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('structured')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'structured'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Interactive Editor
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('json')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'json'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              Raw JSON
            </button>
          </div>

          <button
            type="button"
            onClick={copyToClipboard}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition-colors"
            title="Copy JSON Rulebook"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copy JSON</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Tab 1: Interactive Structured Editor */}
      {activeTab === 'structured' && (
        <div className="space-y-6">
          {/* Top row: Agent Name & Goal */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Agent Name
              </label>
              <input
                type="text"
                value={rulebook.agentName}
                onChange={(e) => updateField('agentName', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Business
              </label>
              <input
                type="text"
                value={rulebook.businessName}
                onChange={(e) => updateField('businessName', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Tone & Demeanor
              </label>
              <input
                type="text"
                value={rulebook.personality?.tone || ''}
                readOnly
                className="w-full bg-slate-950/60 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-400 cursor-not-allowed"
              />
            </div>
          </div>

          {/* Spoken Messages */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                Greeting / First Spoken Message
              </label>
              <textarea
                rows={2}
                value={rulebook.conversationFlow?.firstMessage || ''}
                onChange={(e) => updateField('firstMessage', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[11px] text-slate-500">
                Spoken aloud automatically as soon as the customer connects to the voice agent.
              </span>
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Fallback / Clarification Message
              </label>
              <textarea
                rows={2}
                value={rulebook.conversationFlow?.fallbackMessage || ''}
                onChange={(e) => updateField('fallbackMessage', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[11px] text-slate-500">
                Triggered when speech is muffled or customer asks an out-of-scope question.
              </span>
            </div>
          </div>

          {/* System Prompt */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Full Conversational System Prompt
              </label>
              <span className="text-[11px] text-slate-500">Sent directly to ElevenLabs Agent Configuration</span>
            </div>
            <textarea
              rows={5}
              value={rulebook.systemPrompt}
              onChange={(e) => updateField('systemPrompt', e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Guardrails Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-xs font-semibold text-rose-400 uppercase tracking-wider">
                <ShieldAlert className="w-4 h-4" />
                Strict Agent Guardrails & Safety Boundaries ({rulebook.guardrails?.length || 0})
              </label>
              <button
                type="button"
                onClick={addGuardrail}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-medium border border-rose-500/20 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add Guardrail
              </button>
            </div>

            <div className="space-y-2">
              {rulebook.guardrails?.map((rail, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-xs font-mono text-rose-400 w-5">{idx + 1}.</span>
                  <input
                    type="text"
                    value={rail}
                    onChange={(e) => updateGuardrail(idx, e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
                  />
                  <button
                    type="button"
                    onClick={() => removeGuardrail(idx)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Remove guardrail"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Knowledge Base Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                <BookOpen className="w-4 h-4" />
                Knowledge Base Topics ({rulebook.knowledgeBase?.length || 0})
              </label>
              <button
                type="button"
                onClick={addKbItem}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs font-medium border border-emerald-500/20 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add Topic
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {rulebook.knowledgeBase?.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2 relative group"
                >
                  <div className="flex items-center justify-between">
                    <input
                      type="text"
                      value={item.topic}
                      onChange={(e) => updateKbItem(idx, 'topic', e.target.value)}
                      className="bg-transparent text-xs font-bold text-indigo-300 border-b border-transparent focus:border-indigo-500 focus:outline-none w-3/4"
                    />
                    <button
                      type="button"
                      onClick={() => removeKbItem(idx)}
                      className="p-1 text-slate-500 hover:text-rose-400 opacity-60 group-hover:opacity-100 transition-all"
                      title="Delete topic"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <textarea
                    rows={2}
                    value={item.details}
                    onChange={(e) => updateKbItem(idx, 'details', e.target.value)}
                    className="w-full bg-slate-900/60 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Raw JSON Editor */}
      {activeTab === 'json' && (
        <div className="space-y-3">
          {jsonError && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>
                <strong>Syntax Error:</strong> {jsonError}
              </span>
            </div>
          )}

          <div className="relative">
            <textarea
              rows={18}
              value={jsonText}
              onChange={(e) => handleJsonChange(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-indigo-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 leading-relaxed"
              spellCheck={false}
            />
          </div>
        </div>
      )}

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
        <button
          type="button"
          onClick={onBack}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Edit Business Blueprint
        </button>

        <button
          type="button"
          onClick={onProceed}
          disabled={!!jsonError}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
        >
          <span>Configure Voice & Deploy</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
