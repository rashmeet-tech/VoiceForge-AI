import React from 'react';
import { Mic, Sparkles, ShieldCheck, AlertCircle } from 'lucide-react';
import { ConfigStatus } from '../types';

interface HeaderProps {
  config: ConfigStatus | null;
  currentStep: number;
}

export const Header: React.FC<HeaderProps> = ({ config, currentStep }) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-400 p-0.5 shadow-lg shadow-indigo-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Mic className="w-5 h-5 text-indigo-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                VoiceForge <span className="text-indigo-400">AI</span>
              </h1>
              <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                Hackathon Edition
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Business Description <span className="text-slate-500">→</span> Structured Rulebook <span className="text-slate-500">→</span> ElevenLabs Voice Agent
            </p>
          </div>
        </div>

        {/* Step Progress Pills */}
        <div className="flex items-center gap-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
          <div
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              currentStep === 1
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                : 'text-slate-400'
            }`}
          >
            1. Describe Business
          </div>
          <span className="text-slate-600">›</span>
          <div
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              currentStep === 2
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                : 'text-slate-400'
            }`}
          >
            2. Review Rulebook
          </div>
          <span className="text-slate-600">›</span>
          <div
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              currentStep === 3
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                : 'text-slate-400'
            }`}
          >
            3. Deploy ElevenLabs
          </div>
        </div>

        {/* Status indicator */}
        <div className="flex items-center gap-3">
          {config?.hasElevenLabsKey ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-xs font-medium border border-emerald-500/20">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>ElevenLabs Connected</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-300 text-xs font-medium border border-amber-500/20">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>No ElevenLabs Key (.env)</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
