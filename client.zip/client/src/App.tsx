import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StatusBanner } from './components/StatusBanner';
import { BusinessForm } from './components/BusinessForm';
import { RulebookReviewer } from './components/RulebookReviewer';
import { AgentDeployer } from './components/AgentDeployer';
import { AgentSuccessModal } from './components/AgentSuccessModal';
import { BusinessFormData, ConfigStatus, CreatedAgentResponse, Rulebook } from './types';
import { createAgent, fetchConfigStatus, generateRulebook } from './api';
import { AlertCircle, X } from 'lucide-react';

export const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [config, setConfig] = useState<ConfigStatus | null>(null);

  const [formData, setFormData] = useState<BusinessFormData>({
    businessName: '',
    industry: '',
    description: '',
    targetAudience: '',
    desiredTone: '',
    keyServices: '',
    customConstraints: ''
  });

  const [rulebook, setRulebook] = useState<Rulebook | null>(null);
  const [createdAgent, setCreatedAgent] = useState<CreatedAgentResponse | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    fetchConfigStatus()
      .then((cfg) => setConfig(cfg))
      .catch((err) => console.warn('Could not load config status:', err.message));
  }, []);

  const handleGenerateRulebook = async () => {
    try {
      setIsLoading(true);
      setErrorMessage(null);
      const generated = await generateRulebook(formData);
      setRulebook(generated);
      setCurrentStep(2);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate Rulebook');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeployAgent = async (voiceId: string, agentNameOverride: string) => {
    if (!rulebook) return;
    try {
      setIsLoading(true);
      setErrorMessage(null);
      const agent = await createAgent(rulebook, voiceId, agentNameOverride);
      setCreatedAgent(agent);
      setCurrentStep(4);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to deploy voice agent on ElevenLabs');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setCurrentStep(1);
    setCreatedAgent(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080c14] text-slate-100">
      {/* Header */}
      <Header config={config} currentStep={currentStep} />

      {/* API Key Status Notice */}
      <StatusBanner config={config} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Error notification */}
        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-start justify-between gap-3 shadow-lg">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-rose-200">Action Failed</p>
                <p className="text-xs text-rose-300/90 mt-0.5">{errorMessage}</p>
              </div>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 1: Input Business Blueprint */}
        {currentStep === 1 && (
          <BusinessForm
            formData={formData}
            setFormData={setFormData}
            onGenerate={handleGenerateRulebook}
            isLoading={isLoading}
          />
        )}

        {/* Step 2: Review and Edit Rulebook */}
        {currentStep === 2 && rulebook && (
          <RulebookReviewer
            rulebook={rulebook}
            setRulebook={setRulebook}
            onProceed={() => setCurrentStep(3)}
            onBack={() => setCurrentStep(1)}
          />
        )}

        {/* Step 3: Configure Voice & Deploy to ElevenLabs */}
        {currentStep === 3 && rulebook && (
          <AgentDeployer
            rulebook={rulebook}
            config={config}
            onDeploy={handleDeployAgent}
            onBack={() => setCurrentStep(2)}
            isLoading={isLoading}
          />
        )}

        {/* Step 4: Success & Live Agent Details */}
        {currentStep === 4 && createdAgent && rulebook && (
          <AgentSuccessModal
            agent={createdAgent}
            rulebook={rulebook}
            onReset={handleReset}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>VoiceForge AI • Conversational Voice Agent Architect • Powered by React, Express & ElevenLabs API</p>
      </footer>
    </div>
  );
};

export default App;
