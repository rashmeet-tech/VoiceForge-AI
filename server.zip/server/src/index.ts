import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import rulebookRoutes from './routes/rulebookRoutes.js';
import elevenLabsRoutes from './routes/elevenLabsRoutes.js';
import configRoutes from './routes/configRoutes.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Health Check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'VoiceForge AI API',
    timestamp: new Date().toISOString()
  });
});

// API Routes
app.use('/api/rulebook', rulebookRoutes);
app.use('/api/elevenlabs', elevenLabsRoutes);
app.use('/api/config', configRoutes);

// Global Error Handler
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    success: false,
    error: err.message || 'Internal Server Error'
  });
});

app.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`🎙️  VoiceForge AI Server running on port ${PORT}`);
  console.log(`🔗 Health check: http://localhost:${PORT}/api/health`);
  console.log(`===============================================`);
});
