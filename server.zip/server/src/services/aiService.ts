import axios from 'axios';
import { GenerateRulebookInput, Rulebook } from '../types/rulebook.js';

export class AIService {
  /**
   * Generates a structured Rulebook JSON from user input.
   * Uses Gemini API or OpenAI API if keys are provided,
   * otherwise falls back to the intelligent synthesizer.
   */
  public static async generateRulebook(input: GenerateRulebookInput): Promise<Rulebook> {
    const geminiKey = process.env.GEMINI_API_KEY?.trim();
    const openaiKey = process.env.OPENAI_API_KEY?.trim();

    if (geminiKey) {
      try {
        return await this.generateWithGemini(input, geminiKey);
      } catch (err: any) {
        console.warn('Gemini generation failed, falling back to intelligent synthesizer:', err.message);
      }
    }

    if (openaiKey) {
      try {
        return await this.generateWithOpenAI(input, openaiKey);
      } catch (err: any) {
        console.warn('OpenAI generation failed, falling back to intelligent synthesizer:', err.message);
      }
    }

    // Default intelligent synthesizer
    return this.synthesizeRulebook(input);
  }

  private static buildSystemInstruction(): string {
    return `You are VoiceForge AI, an expert conversational voice architect.
Your task is to take a business description and generate a complete, structured JSON Rulebook for an ElevenLabs Conversational Voice Agent.
The JSON must strictly conform to this schema:
{
  "agentName": "string (e.g. Maya - SmileCare Dental Assistant)",
  "businessName": "string",
  "industry": "string",
  "primaryGoal": "string",
  "personality": {
    "tone": "string (e.g. Warm, empathetic, professional)",
    "style": "string (e.g. Concise and reassuring phone representative)",
    "language": "en"
  },
  "conversationFlow": {
    "firstMessage": "string (First thing the agent says when answering the call)",
    "fallbackMessage": "string (What agent says when confused or unable to answer)",
    "endConversationMessage": "string (Polite sign-off)"
  },
  "systemPrompt": "string (Detailed prompt instructing the AI on behavior, persona, rules, and handling inquiries concisely)",
  "knowledgeBase": [
    { "topic": "string", "details": "string" }
  ],
  "guardrails": [
    "string (Crucial constraint/limitation, e.g. Do not give medical diagnoses)"
  ],
  "voiceSettings": {
    "suggestedVoiceId": "string (Elevenlabs voice ID or leave default 21m00Tcm4TlvDq8ikWAM)",
    "voiceName": "string",
    "temperature": 0.5,
    "stability": 0.7
  }
}
Return ONLY valid JSON. No markdown backticks, no explanations.`;
  }

  private static async generateWithGemini(input: GenerateRulebookInput, apiKey: string): Promise<Rulebook> {
    const prompt = `Generate a voice agent Rulebook for this business:
Business Name: ${input.businessName || 'Auto-detect'}
Industry: ${input.industry || 'Auto-detect'}
Description: ${input.description}
Audience: ${input.targetAudience || 'General public'}
Desired Tone: ${input.desiredTone || 'Professional and friendly'}
Services: ${input.keyServices?.join(', ') || 'Auto-detect'}
Constraints: ${input.customConstraints?.join(', ') || 'Standard safety guardrails'}`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    const response = await axios.post(
      url,
      {
        contents: [
          {
            role: 'user',
            parts: [
              { text: this.buildSystemInstruction() },
              { text: prompt }
            ]
          }
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.7
        }
      },
      { timeout: 30000 }
    );

    const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) {
      throw new Error('Empty response from Gemini API');
    }

    return JSON.parse(text);
  }

  private static async generateWithOpenAI(input: GenerateRulebookInput, apiKey: string): Promise<Rulebook> {
    const prompt = `Generate a voice agent Rulebook for this business:
Business Name: ${input.businessName || 'Auto-detect'}
Industry: ${input.industry || 'Auto-detect'}
Description: ${input.description}
Audience: ${input.targetAudience || 'General public'}
Desired Tone: ${input.desiredTone || 'Professional and friendly'}
Services: ${input.keyServices?.join(', ') || 'Auto-detect'}
Constraints: ${input.customConstraints?.join(', ') || 'Standard safety guardrails'}`;

    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: this.buildSystemInstruction() },
          { role: 'user', content: prompt }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.7
      },
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000
      }
    );

    const content = response.data?.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error('Empty response from OpenAI');
    }

    return JSON.parse(content);
  }

  /**
   * Smart rulebook synthesizer when no external LLM key is configured.
   * Produces high quality, relevant rulebooks based on keywords and description.
   */
  public static synthesizeRulebook(input: GenerateRulebookInput): Rulebook {
    const raw = (input.description + ' ' + (input.businessName || '') + ' ' + (input.industry || '')).toLowerCase();

    let businessName = input.businessName?.trim();
    let industry = input.industry?.trim();
    let tone = input.desiredTone?.trim() || 'Friendly, professional, and clear';

    // Industry inference
    if (!industry) {
      if (raw.includes('dental') || raw.includes('clinic') || raw.includes('doctor') || raw.includes('patient') || raw.includes('health')) {
        industry = 'Healthcare & Medical';
      } else if (raw.includes('real estate') || raw.includes('property') || raw.includes('home') || raw.includes('apartment')) {
        industry = 'Real Estate';
      } else if (raw.includes('restaurant') || raw.includes('food') || raw.includes('cafe') || raw.includes('dining') || raw.includes('table')) {
        industry = 'Hospitality & Dining';
      } else if (raw.includes('ecommerce') || raw.includes('shop') || raw.includes('store') || raw.includes('order') || raw.includes('shipping')) {
        industry = 'E-Commerce & Retail';
      } else if (raw.includes('tech') || raw.includes('software') || raw.includes('saas') || raw.includes('app')) {
        industry = 'Technology & Software';
      } else {
        industry = 'Customer Services';
      }
    }

    // Business Name inference
    if (!businessName) {
      const words = input.description.split(/\s+/).slice(0, 3).join(' ');
      businessName = words.length > 3 ? words.replace(/[^\w\s]/gi, '') + ' Services' : 'VoiceForge Client';
    }

    const agentName = `${businessName} AI Assistant`;

    // Dynamic first message based on industry
    let firstMessage = `Hello! Thank you for calling ${businessName}. How can I assist you today?`;
    let fallback = `I want to make sure I get you the exact information you need. Could you please clarify that or let me connect you with a live representative?`;
    let signOff = `Thank you for contacting ${businessName}. Have a wonderful day! Goodbye.`;

    const knowledgeBase = [
      {
        topic: 'Business Overview',
        details: `${businessName} operates in the ${industry} sector. ${input.description.slice(0, 300)}`
      },
      {
        topic: 'Operating Hours',
        details: 'Monday to Friday: 9:00 AM to 6:00 PM. Weekend support available via online request.'
      },
      {
        topic: 'Contact and Inquiries',
        details: 'Callers can schedule appointments, inquire about services, or request a callback from a senior specialist.'
      }
    ];

    if (input.keyServices && input.keyServices.length > 0) {
      knowledgeBase.push({
        topic: 'Key Services & Offerings',
        details: input.keyServices.join('; ')
      });
    }

    const guardrails = [
      'Never fabricate pricing or legal/contractual commitments without verification.',
      'Maintain polite, conversational, and concise responses suitable for a spoken voice call.',
      'If the caller is frustrated or reporting an urgent issue, offer to escalate immediately.',
      ...(input.customConstraints || [])
    ];

    if (industry.includes('Healthcare') || raw.includes('medic') || raw.includes('dental')) {
      guardrails.push('Never diagnose medical conditions or give definitive medical advice. For emergencies, advise calling 911 or visiting the ER.');
    }

    const systemPrompt = `You are ${agentName}, the official AI voice receptionist for ${businessName}.
Your objective is to provide quick, helpful, and natural spoken assistance over the phone.

Key Guidelines:
1. Speak concisely in 1 to 3 spoken sentences per turn. Never read long lists or bullet points aloud.
2. Tone: ${tone}.
3. Handle caller requests such as appointments, FAQs, and service overviews.
4. If you don't know the answer, use the fallback message and offer to take their contact info or transfer them.

Knowledge Context:
${knowledgeBase.map((k) => `- ${k.topic}: ${k.details}`).join('\n')}

Guardrails:
${guardrails.map((g) => `- ${g}`).join('\n')}`;

    return {
      agentName,
      businessName,
      industry,
      primaryGoal: `Handle inbound customer calls, answer FAQs, and direct inquiries for ${businessName}`,
      personality: {
        tone,
        style: 'Concise, empathetic, and professional phone representative',
        language: 'en'
      },
      conversationFlow: {
        firstMessage,
        fallbackMessage: fallback,
        endConversationMessage: signOff
      },
      systemPrompt,
      knowledgeBase,
      guardrails,
      voiceSettings: {
        suggestedVoiceId: '21m00Tcm4TlvDq8ikWAM', // Rachel
        voiceName: 'Rachel (Calm & Professional)',
        temperature: 0.5,
        stability: 0.7
      }
    };
  }
}
