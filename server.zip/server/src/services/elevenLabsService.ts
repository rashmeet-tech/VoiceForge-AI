import axios from 'axios';
import { CreateAgentRequest, ElevenLabsVoice, Rulebook } from '../types/rulebook.js';

const ELEVENLABS_BASE_URL = 'https://api.elevenlabs.io/v1';

export const FALLBACK_VOICES: ElevenLabsVoice[] = [
  {
    voice_id: '21m00Tcm4TlvDq8ikWAM',
    name: 'Rachel',
    category: 'premade',
    description: 'Calm, professional, conversational female voice (Default)'
  },
  {
    voice_id: 'AZnzlk1XvdvUeBnXmlld',
    name: 'Domi',
    category: 'premade',
    description: 'Strong, engaged, friendly female voice'
  },
  {
    voice_id: 'EXAVITQu4vr4xnSDxMaL',
    name: 'Bella',
    category: 'premade',
    description: 'Soft, gentle, pleasant female voice'
  },
  {
    voice_id: 'ErXwobaYiN019PkySvjV',
    name: 'Antoni',
    category: 'premade',
    description: 'Well-rounded, warm, natural male voice'
  },
  {
    voice_id: 'pNInz6obpgDQGcFmaJgB',
    name: 'Adam',
    category: 'premade',
    description: 'Deep, confident, narrative male voice'
  },
  {
    voice_id: 'piTKgcLEGmPE4e6mEKli',
    name: 'Nicole',
    category: 'premade',
    description: 'Whispering, gentle, focused voice'
  }
];

export class ElevenLabsService {
  private static getApiKey(): string {
    const key = process.env.ELEVENLABS_API_KEY?.trim();
    if (!key || key === 'your_elevenlabs_api_key_here') {
      throw new Error(
        'ELEVENLABS_API_KEY is not set in server/.env. Please configure it to create live voice agents.'
      );
    }
    return key;
  }

  /**
   * Fetch available voices from ElevenLabs or return curated defaults.
   */
  public static async getVoices(): Promise<{ voices: ElevenLabsVoice[]; isLive: boolean }> {
    try {
      const apiKey = this.getApiKey();
      const response = await axios.get(`${ELEVENLABS_BASE_URL}/voices`, {
        headers: {
          'xi-api-key': apiKey
        },
        timeout: 10000
      });

      const voices: ElevenLabsVoice[] = (response.data?.voices || []).map((v: any) => ({
        voice_id: v.voice_id,
        name: v.name,
        category: v.category,
        description: v.labels?.description || v.description || `${v.labels?.accent || ''} ${v.labels?.gender || ''}`.trim(),
        preview_url: v.preview_url
      }));

      return { voices: voices.length > 0 ? voices : FALLBACK_VOICES, isLive: true };
    } catch (err: any) {
      console.warn('Could not fetch voices from ElevenLabs API (using curated defaults):', err.message);
      return { voices: FALLBACK_VOICES, isLive: false };
    }
  }

  /**
   * Creates a Conversational AI Agent on ElevenLabs using the structured Rulebook.
   */
  public static async createAgent(request: CreateAgentRequest): Promise<{
    agentId: string;
    name: string;
    voiceId: string;
    dashboardUrl: string;
    shareableUrl: string;
    widgetSnippet: string;
  }> {
    const apiKey = this.getApiKey();
    const rulebook = request.rulebook;

    const agentName = request.agentNameOverride || rulebook.agentName || `${rulebook.businessName} Assistant`;
    const voiceId = request.voiceId || rulebook.voiceSettings?.suggestedVoiceId || '21m00Tcm4TlvDq8ikWAM';
    const firstMessage = rulebook.conversationFlow?.firstMessage || `Hello! Thank you for calling ${rulebook.businessName}. How may I help you?`;
    
    // Construct robust conversational system prompt including guardrails and knowledge base
    const fullSystemPrompt = this.compileAgentPrompt(rulebook);

    const payload = {
      name: agentName,
      conversation_config: {
        agent: {
          prompt: {
            prompt: fullSystemPrompt
          },
          first_message: firstMessage,
          language: rulebook.personality?.language || 'en'
        },
        tts: {
          voice_id: voiceId
        }
      }
    };

    try {
      const response = await axios.post(`${ELEVENLABS_BASE_URL}/convai/agents/create`, payload, {
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: 20000
      });

      const agentId = response.data?.agent_id;
      if (!agentId) {
        throw new Error('ElevenLabs API response did not contain an agent_id');
      }

      const dashboardUrl = `https://elevenlabs.io/app/conversational-ai/${agentId}`;
      const shareableUrl = `https://elevenlabs.io/app/conversational-ai/${agentId}`;
      const widgetSnippet = `<elevenlabs-convai agent-id="${agentId}"></elevenlabs-convai><script src="https://elevenlabs.io/convai-widget/index.js" async type="text/javascript"></script>`;

      return {
        agentId,
        name: agentName,
        voiceId,
        dashboardUrl,
        shareableUrl,
        widgetSnippet
      };
    } catch (err: any) {
      const errorDetail = err.response?.data?.detail?.message || err.response?.data?.message || err.message;
      throw new Error(`ElevenLabs Agent Creation Failed: ${errorDetail}`);
    }
  }

  /**
   * Compiles the Rulebook into a complete prompt ready for conversational execution.
   */
  private static compileAgentPrompt(rulebook: Rulebook): string {
    const kbSection = (rulebook.knowledgeBase || [])
      .map((item) => `[${item.topic}]: ${item.details}`)
      .join('\n');

    const guardrailSection = (rulebook.guardrails || [])
      .map((g, idx) => `${idx + 1}. ${g}`)
      .join('\n');

    return `${rulebook.systemPrompt || ''}

=== BUSINESS CONTEXT ===
Business Name: ${rulebook.businessName}
Industry: ${rulebook.industry}
Primary Objective: ${rulebook.primaryGoal}
Voice Tone & Demeanor: ${rulebook.personality?.tone || 'Helpful and professional'}

=== KNOWLEDGE BASE ===
${kbSection || 'None specified.'}

=== STRICT GUARDRAILS & LIMITATIONS ===
${guardrailSection || 'Standard customer service guidelines.'}

=== FALLBACK INSTRUCTION ===
If you encounter an inquiry you cannot answer with high confidence, state:
"${rulebook.conversationFlow?.fallbackMessage || 'I am not certain about that. Let me direct you to our team.'}"
`;
  }
}
