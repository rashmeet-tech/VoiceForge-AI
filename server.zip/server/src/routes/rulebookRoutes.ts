import { Router, Request, Response } from 'express';
import { AIService } from '../services/aiService.js';
import { GenerateRulebookInput, Rulebook } from '../types/rulebook.js';

const router = Router();

// POST /api/rulebook/generate
router.post('/generate', async (req: Request, res: Response) => {
  try {
    const input: GenerateRulebookInput = req.body;

    if (!input.description || input.description.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Please provide a business description to generate the Rulebook.'
      });
    }

    const rulebook = await AIService.generateRulebook(input);

    return res.json({
      success: true,
      rulebook
    });
  } catch (error: any) {
    console.error('Error generating rulebook:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate Rulebook'
    });
  }
});

// POST /api/rulebook/validate
router.post('/validate', (req: Request, res: Response) => {
  try {
    const rulebook: Rulebook = req.body.rulebook;

    const errors: string[] = [];
    if (!rulebook.agentName?.trim()) errors.push('agentName is required');
    if (!rulebook.businessName?.trim()) errors.push('businessName is required');
    if (!rulebook.systemPrompt?.trim()) errors.push('systemPrompt is required');
    if (!rulebook.conversationFlow?.firstMessage?.trim()) errors.push('conversationFlow.firstMessage is required');

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        valid: false,
        errors
      });
    }

    return res.json({
      success: true,
      valid: true
    });
  } catch (error: any) {
    return res.status(400).json({
      success: false,
      valid: false,
      errors: [error.message || 'Malformed Rulebook JSON']
    });
  }
});

export default router;
