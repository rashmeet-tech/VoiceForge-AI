import { Router, Request, Response } from 'express';

const router = Router();

// GET /api/config/status
router.get('/status', (_req: Request, res: Response) => {
  const elevenLabsKey = process.env.ELEVENLABS_API_KEY?.trim();
  const hasElevenLabsKey = !!elevenLabsKey && elevenLabsKey !== 'your_elevenlabs_api_key_here';

  const geminiKey = process.env.GEMINI_API_KEY?.trim();
  const hasGeminiKey = !!geminiKey && geminiKey.length > 5;

  const openaiKey = process.env.OPENAI_API_KEY?.trim();
  const hasOpenaiKey = !!openaiKey && openaiKey.length > 5;

  res.json({
    hasElevenLabsKey,
    hasGeminiKey,
    hasOpenaiKey,
    mode: hasElevenLabsKey ? 'ready' : 'setup_needed'
  });
});

export default router;
