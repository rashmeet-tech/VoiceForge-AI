import { Router, Request, Response } from 'express';
import { ElevenLabsService } from '../services/elevenLabsService.js';
import { CreateAgentRequest } from '../types/rulebook.js';

const router = Router();

// GET /api/elevenlabs/voices
router.get('/voices', async (_req: Request, res: Response) => {
  try {
    const { voices, isLive } = await ElevenLabsService.getVoices();
    return res.json({
      success: true,
      voices,
      isLive
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch voices'
    });
  }
});

// POST /api/elevenlabs/agents
router.post('/agents', async (req: Request, res: Response) => {
  try {
    const request: CreateAgentRequest = req.body;

    if (!request.rulebook) {
      return res.status(400).json({
        success: false,
        error: 'Missing rulebook in request body'
      });
    }

    const result = await ElevenLabsService.createAgent(request);

    return res.json({
      success: true,
      data: result
    });
  } catch (error: any) {
    console.error('Error creating ElevenLabs agent:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to create agent in ElevenLabs'
    });
  }
});

export default router;
