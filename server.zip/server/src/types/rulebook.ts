export interface KnowledgeItem {
  topic: string;
  details: string;
}

export interface RulebookPersonality {
  tone: string;
  style: string;
  language: string;
}

export interface ConversationFlow {
  firstMessage: string;
  fallbackMessage: string;
  endConversationMessage: string;
}

export interface VoiceSettings {
  suggestedVoiceId: string;
  voiceName?: string;
  temperature?: number;
  stability?: number;
}

export interface Rulebook {
  agentName: string;
  businessName: string;
  industry: string;
  primaryGoal: string;
  personality: RulebookPersonality;
  conversationFlow: ConversationFlow;
  systemPrompt: string;
  knowledgeBase: KnowledgeItem[];
  guardrails: string[];
  voiceSettings: VoiceSettings;
}

export interface GenerateRulebookInput {
  businessName?: string;
  industry?: string;
  description: string;
  targetAudience?: string;
  desiredTone?: string;
  keyServices?: string[];
  customConstraints?: string[];
}

export interface CreateAgentRequest {
  rulebook: Rulebook;
  voiceId?: string;
  agentNameOverride?: string;
}

export interface ElevenLabsVoice {
  voice_id: string;
  name: string;
  category?: string;
  description?: string;
  preview_url?: string;
}
